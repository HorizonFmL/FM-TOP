This overlay is under development and can be subject to change.
Copyrights haven't been filled out yet, but when it's done, it will be free for personal and commercial use.

Until the copyright issue is solved, please do not use this overlay during streams or show it in videos.

During installation, make sure to check the "Install dashboard fonts" option and restart the Simhub application.

The font used in this project is in the Google Fonts project and copyrighted for free use.

For getting the optimal placement and size at 1080p displays, you can copy olayout file to "C:\Program Files (x86)\SimHub\OverlayLayouts"

For lower CPU overhead during use, the renderer can be changed to HTML WebView2.

!!! DISCLAIMERS !!!

This overlay during use triggers the action 'PersistantTrackerPlugin.ClearLapHistory' due to the limitations of Forza Motorsports. If you want to use Persistant Tracker Plugin's futures with the given track and car combo, DO NOT USE THIS OVERLAY without making manual backups of the plugin's data.

This overlay doesn't check the sim that is running, and leaving it open while playing other games that connect to Simhub can have the same affect as the first disclaimer point. The usability of the overlay in other games has not been tested.